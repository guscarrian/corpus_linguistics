import os

entries = os.listdir('/home/andrea/EN2033/final_project/doctor_who_corpus/prueba')
for entry in entries:
    #print(entry)

